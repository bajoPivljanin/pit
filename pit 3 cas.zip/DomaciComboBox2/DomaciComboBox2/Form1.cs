﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DomaciComboBox2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label2.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBox1.Text);
            int suma = 0, j = 0;
            for (int i = 1; i < n; i++)
            {
                if (n % i == 0)
                {
                    j = i;
                    suma = suma + j;
                    j--;
                }
            }
            if (suma == n)
            {
                label2.Text = "Broj " + n + " je savrsen";
            }
            else
            {
                label2.Text = "Broj " + n + " nije savrsen";
            }
        }
    }
}
