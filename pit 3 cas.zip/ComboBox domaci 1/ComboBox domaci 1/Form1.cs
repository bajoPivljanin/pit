﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComboBox_domaci_1
{
    public partial class Form1 : Form
    {
        private int suma = 0, max = 0, min = 100;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int temperatura = Convert.ToInt32(textBox2.Text), brdana = Convert.ToInt32(textBox1.Text);
            suma = suma + Convert.ToInt32(textBox2.Text);
            listBox1.Items.Add(temperatura);
            int a = listBox1.Items.Count + 1;
            label2.Text = "Temperatura " + a + ". dana";
            if (temperatura > max)
                max = temperatura;
            if (temperatura < min)
                min = temperatura;
            if (brdana == listBox1.Items.Count)
            {
                groupBox1.Enabled = true;
                button1.Enabled = false;
            }
            textBox2.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            groupBox1.Enabled = false;
            label2.Text = "Temperatura 1. dana:";
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            int brdana = Convert.ToInt32(textBox1.Text);
            float prosek = (float)suma / brdana;
            label3.Text = prosek.ToString();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label3.Text = max.ToString();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            label3.Text = min.ToString();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            int raspon = max - min;
            label3.Text = raspon.ToString();
        }
    }
}
