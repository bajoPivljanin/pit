﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComboBox_prost
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listBox1.Hide();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            int n;
            n = Convert.ToInt32(textBox1.Text);
            if (radioButton1.Checked)
            {
                label2.Show();
                listBox1.Hide();
                int prost = 0;
                for (int i = 1; i <= n; i++)
                {
                    if (n % i == 0)
                    {
                        prost++;
                    }
                }
                if (prost == 2)
                {
                    label2.Text = " Ovaj broj je prost";
                }
                else
                {
                    label2.Text = " Ovaj broj nije prost";
                }
            }
            if (radioButton2.Checked)
            {
                n = Convert.ToInt32(textBox1.Text);
                label2.Hide();
                listBox1.Show();
                int i, j, prost;
                listBox1.Items.Clear();
                for (i = 2; i <= n; i++)
                {
                    prost = 1;
                    for (j = 2; j <= i / 2; j++)
                    {
                        if (i % j == 0)
                        {
                            prost = 0;
                            break;
                        }
                    }
                    if (prost == 1)
                    {
                        listBox1.Items.Add(i);

                    }
                }
            }
        }
    }
}
