﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComboBox3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string[] naselja = new string[]
            {
                "Senta", "Kanjiža", "Sombor", "Bačka Topola", "Martonoš", "Bikovo", "Bajmok", "Pačir", "Čantavir", "Tornjoš", "Palić", "Kelebija", "Tavankut"
            };

        private void button1_Click(object sender, EventArgs e)
        {
            string naselje = "";
            string kucnibroj = textBox2.Text;
            string ulica = textBox1.Text;
            if (radioButton1.Checked)
                naselje = "Subotica";
            else
            {
                naselje = comboBox1.Text;
            }
            string novired = naselje + "  " + ulica + "  " + kucnibroj;
            listBox1.Items.Add(novired);
            textBox1.Text = textBox2.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = naselja;
            if (radioButton1.Checked)
                comboBox1.Enabled = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
                comboBox1.Enabled = true;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                comboBox1.Enabled = false;
        }
    }
}
