﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication13
{
    public partial class Form1 : Form
    {
        private int srpskiBroj, madjarskiBroj, elektroBroj, masinstvoBroj, saobracajBroj;
        public Form1()
        {
            InitializeComponent();
            lbSviPodaciUcenika.Items.Clear();
            srpskiBroj = madjarskiBroj = elektroBroj = masinstvoBroj = saobracajBroj = 0;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            string[] jezik = new string[]
            {
                "Srpski", "Mađarski"
            };
            cbNastavniJezik.DataSource = jezik;
            cbNastavniJezik.Text = "Izaberi jezik";
            string[] podrucjeRada = new string[]
            {
                "Elektrotehnika", "Mašinstvo", "Saobraćaj"
            };
            cbPodrucjeRada.DataSource = podrucjeRada;
            cbPodrucjeRada.Text = "Izaberi područje rada";
        }
        private void btnUnos_Click(object sender, EventArgs e)
        {
            String ime, razred, jezik, smer;
            ime = razred = jezik = smer = "";
            ime = txtImeUcenika.Text;
            if (ime == "") MessageBox.Show("Upiši ime učenika !!!");
            else
            {
                jezik = cbNastavniJezik.SelectedItem.ToString();
                smer = cbPodrucjeRada.SelectedItem.ToString();
                if (rbPrvi.Checked) razred = "Prvi";
                if (rbDrugi.Checked) razred = "Drugi";
                if (rbTreci.Checked) razred = "Treći";
                if (rbCetvrti.Checked) razred = "Četvrti";
                lbSviPodaciUcenika.Items.Add(ime + "   " + razred + "   " + jezik + "   " + smer);
                txtImeUcenika.Text = "";
                if (jezik == "Srpski") srpskiBroj++;

                if (jezik == "Mađarski") madjarskiBroj++;
                if (smer == "Elektrotehnika") elektroBroj++;
                if (smer == "Mašinstvo") masinstvoBroj++;
                if (smer == "Saobraćaj") saobracajBroj++;
                lblSrpski.Text = srpskiBroj.ToString();
                lblMadjarski.Text = madjarskiBroj.ToString();
                lblElektrotehnika.Text = elektroBroj.ToString();
                lblMasinstvo.Text = masinstvoBroj.ToString();
                lblSaobracaj.Text = saobracajBroj.ToString();
                }
          }
    }

}
