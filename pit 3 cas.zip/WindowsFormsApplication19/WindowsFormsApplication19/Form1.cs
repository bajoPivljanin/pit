﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        int d = 1;
        int n;
        double suma = 0;
        int max = -100;
        int min = 100;
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            double prosek = suma / n;
            label3.Text = prosek.ToString();
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label3.Text = max.ToString();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            label3.Text = min.ToString();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            label3.Text = (max - min).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int t, d1;
            n = Convert.ToInt32(textBox1.Text);
            if (d <= n)
                {
                d1 = d;
                d1++;
                if (d == n)
                {
                }
                else
                    label2.Text = " Temperatura " +d1 + ". dana je" ;
                d++;
                listBox1.Items.Add(textBox2.Text);
                t = Convert.ToInt32(textBox2.Text);
                suma = suma + t;
                if (max < t)
                {
                    max = t;
                }
                if (min > t)
                {
                    min = t;
                }
            }
            if (d <= n)
                {
                radioButton1.Enabled = false;
                radioButton2.Enabled = false;
                radioButton3.Enabled = false;
                radioButton4.Enabled = false;
                }
else
{
                radioButton1.Enabled = true;
                radioButton2.Enabled = true;
                radioButton3.Enabled = true;
                radioButton4.Enabled = true;
            }
            textBox2.Text = " " ;
            if (d == (n + 1))
            {
                button1.Enabled = false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {   

        }
    }
}
