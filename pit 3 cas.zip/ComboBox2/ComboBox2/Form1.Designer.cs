﻿namespace ComboBox2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtImeUcenika = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbNastavniJezik = new System.Windows.Forms.ComboBox();
            this.cbPodrucjeRada = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbCetvrti = new System.Windows.Forms.RadioButton();
            this.rbTreci = new System.Windows.Forms.RadioButton();
            this.rbDrugi = new System.Windows.Forms.RadioButton();
            this.rbPrvi = new System.Windows.Forms.RadioButton();
            this.btnUnos = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lbSviPodaciUcenika = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblSaobracaj = new System.Windows.Forms.Label();
            this.lblMasinstvo = new System.Windows.Forms.Label();
            this.lblElektrotehnika = new System.Windows.Forms.Label();
            this.lblMadjarski = new System.Windows.Forms.Label();
            this.lblSrpski = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ime ucenika";
            // 
            // txtImeUcenika
            // 
            this.txtImeUcenika.Location = new System.Drawing.Point(83, 9);
            this.txtImeUcenika.Name = "txtImeUcenika";
            this.txtImeUcenika.Size = new System.Drawing.Size(198, 20);
            this.txtImeUcenika.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nastavni jezik";
            // 
            // cbNastavniJezik
            // 
            this.cbNastavniJezik.FormattingEnabled = true;
            this.cbNastavniJezik.Location = new System.Drawing.Point(144, 51);
            this.cbNastavniJezik.Name = "cbNastavniJezik";
            this.cbNastavniJezik.Size = new System.Drawing.Size(137, 21);
            this.cbNastavniJezik.TabIndex = 4;
            // 
            // cbPodrucjeRada
            // 
            this.cbPodrucjeRada.FormattingEnabled = true;
            this.cbPodrucjeRada.Location = new System.Drawing.Point(144, 103);
            this.cbPodrucjeRada.Name = "cbPodrucjeRada";
            this.cbPodrucjeRada.Size = new System.Drawing.Size(137, 21);
            this.cbPodrucjeRada.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(141, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Podrucje rada";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbCetvrti);
            this.groupBox1.Controls.Add(this.rbTreci);
            this.groupBox1.Controls.Add(this.rbDrugi);
            this.groupBox1.Controls.Add(this.rbPrvi);
            this.groupBox1.Location = new System.Drawing.Point(12, 35);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(110, 109);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Razred";
            // 
            // rbCetvrti
            // 
            this.rbCetvrti.AutoSize = true;
            this.rbCetvrti.Location = new System.Drawing.Point(6, 85);
            this.rbCetvrti.Name = "rbCetvrti";
            this.rbCetvrti.Size = new System.Drawing.Size(55, 17);
            this.rbCetvrti.TabIndex = 3;
            this.rbCetvrti.TabStop = true;
            this.rbCetvrti.Text = "Cetvrti";
            this.rbCetvrti.UseVisualStyleBackColor = true;
            // 
            // rbTreci
            // 
            this.rbTreci.AutoSize = true;
            this.rbTreci.Location = new System.Drawing.Point(6, 62);
            this.rbTreci.Name = "rbTreci";
            this.rbTreci.Size = new System.Drawing.Size(49, 17);
            this.rbTreci.TabIndex = 2;
            this.rbTreci.TabStop = true;
            this.rbTreci.Text = "Treci";
            this.rbTreci.UseVisualStyleBackColor = true;
            // 
            // rbDrugi
            // 
            this.rbDrugi.AutoSize = true;
            this.rbDrugi.Location = new System.Drawing.Point(6, 39);
            this.rbDrugi.Name = "rbDrugi";
            this.rbDrugi.Size = new System.Drawing.Size(50, 17);
            this.rbDrugi.TabIndex = 1;
            this.rbDrugi.TabStop = true;
            this.rbDrugi.Text = "Drugi";
            this.rbDrugi.UseVisualStyleBackColor = true;
            // 
            // rbPrvi
            // 
            this.rbPrvi.AutoSize = true;
            this.rbPrvi.Location = new System.Drawing.Point(6, 16);
            this.rbPrvi.Name = "rbPrvi";
            this.rbPrvi.Size = new System.Drawing.Size(43, 17);
            this.rbPrvi.TabIndex = 0;
            this.rbPrvi.TabStop = true;
            this.rbPrvi.Text = "Prvi";
            this.rbPrvi.UseVisualStyleBackColor = true;
            // 
            // btnUnos
            // 
            this.btnUnos.Location = new System.Drawing.Point(144, 130);
            this.btnUnos.Name = "btnUnos";
            this.btnUnos.Size = new System.Drawing.Size(75, 23);
            this.btnUnos.TabIndex = 8;
            this.btnUnos.Text = "Unos";
            this.btnUnos.UseVisualStyleBackColor = true;
            this.btnUnos.Click += new System.EventHandler(this.btnUnos_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Svi podaci ucenika";
            // 
            // lbSviPodaciUcenika
            // 
            this.lbSviPodaciUcenika.FormattingEnabled = true;
            this.lbSviPodaciUcenika.Location = new System.Drawing.Point(12, 182);
            this.lbSviPodaciUcenika.Name = "lbSviPodaciUcenika";
            this.lbSviPodaciUcenika.Size = new System.Drawing.Size(269, 147);
            this.lbSviPodaciUcenika.TabIndex = 10;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.lblSaobracaj);
            this.groupBox2.Controls.Add(this.lblMasinstvo);
            this.groupBox2.Controls.Add(this.lblElektrotehnika);
            this.groupBox2.Controls.Add(this.lblMadjarski);
            this.groupBox2.Controls.Add(this.lblSrpski);
            this.groupBox2.Location = new System.Drawing.Point(12, 336);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(269, 163);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Statistika";
            // 
            // lblSaobracaj
            // 
            this.lblSaobracaj.AutoSize = true;
            this.lblSaobracaj.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaobracaj.Location = new System.Drawing.Point(7, 98);
            this.lblSaobracaj.Name = "lblSaobracaj";
            this.lblSaobracaj.Size = new System.Drawing.Size(74, 16);
            this.lblSaobracaj.TabIndex = 4;
            this.lblSaobracaj.Text = "Saobracaj:";
            // 
            // lblMasinstvo
            // 
            this.lblMasinstvo.AutoSize = true;
            this.lblMasinstvo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMasinstvo.Location = new System.Drawing.Point(7, 128);
            this.lblMasinstvo.Name = "lblMasinstvo";
            this.lblMasinstvo.Size = new System.Drawing.Size(72, 16);
            this.lblMasinstvo.TabIndex = 3;
            this.lblMasinstvo.Text = "Masinstvo:";
            // 
            // lblElektrotehnika
            // 
            this.lblElektrotehnika.AutoSize = true;
            this.lblElektrotehnika.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblElektrotehnika.Location = new System.Drawing.Point(6, 70);
            this.lblElektrotehnika.Name = "lblElektrotehnika";
            this.lblElektrotehnika.Size = new System.Drawing.Size(96, 16);
            this.lblElektrotehnika.TabIndex = 2;
            this.lblElektrotehnika.Text = "Elektrotehnika:";
            // 
            // lblMadjarski
            // 
            this.lblMadjarski.AutoSize = true;
            this.lblMadjarski.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMadjarski.Location = new System.Drawing.Point(7, 42);
            this.lblMadjarski.Name = "lblMadjarski";
            this.lblMadjarski.Size = new System.Drawing.Size(100, 16);
            this.lblMadjarski.TabIndex = 1;
            this.lblMadjarski.Text = "Madjarski jezik:";
            // 
            // lblSrpski
            // 
            this.lblSrpski.AutoSize = true;
            this.lblSrpski.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSrpski.Location = new System.Drawing.Point(6, 16);
            this.lblSrpski.Name = "lblSrpski";
            this.lblSrpski.Size = new System.Drawing.Size(79, 16);
            this.lblSrpski.TabIndex = 0;
            this.lblSrpski.Text = "Srpski jezik:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(129, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(129, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(129, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(13, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(129, 101);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(13, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(129, 130);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(293, 511);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lbSviPodaciUcenika);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnUnos);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbPodrucjeRada);
            this.Controls.Add(this.cbNastavniJezik);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtImeUcenika);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtImeUcenika;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbNastavniJezik;
        private System.Windows.Forms.ComboBox cbPodrucjeRada;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbCetvrti;
        private System.Windows.Forms.RadioButton rbTreci;
        private System.Windows.Forms.RadioButton rbDrugi;
        private System.Windows.Forms.RadioButton rbPrvi;
        private System.Windows.Forms.Button btnUnos;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lbSviPodaciUcenika;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblSaobracaj;
        private System.Windows.Forms.Label lblMasinstvo;
        private System.Windows.Forms.Label lblElektrotehnika;
        private System.Windows.Forms.Label lblMadjarski;
        private System.Windows.Forms.Label lblSrpski;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
    }
}

