﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComboBox2
{
    public partial class Form1 : Form
    {
        private int srpskiBroj, madjarskiBroj, elektroBroj, saobracajBroj, masinstvoBroj;
        public Form1()
        {
            InitializeComponent();
            lbSviPodaciUcenika.Items.Clear();
            srpskiBroj = madjarskiBroj = elektroBroj = saobracajBroj = masinstvoBroj = 0;
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            string[] jezik = new string[]
            {
                "Srpski", "Madjarski"
            };
            cbNastavniJezik.DataSource = jezik;
            cbNastavniJezik.Text = "Izaberi jezik";
            string[] podrucjeRada = new string[]
            {
                "Elektrotehnika", "Masinstvo", "Saobracaj"
            };
            cbPodrucjeRada.DataSource = podrucjeRada;
            cbPodrucjeRada.Text = "Izaberi podrucje rada";
        }

        private void btnUnos_Click(object sender, EventArgs e)
        {
            String ime, razred, jezik, smer;
            ime = razred = jezik = smer = "";
            ime = txtImeUcenika.Text;
            if (ime == "")
                MessageBox.Show("Unesite ime ucenika!");
            else
            {
                jezik = cbNastavniJezik.SelectedItem.ToString();
                smer = cbPodrucjeRada.SelectedItem.ToString();
                if (rbPrvi.Checked)
                    razred = "Prvi";
                if (rbDrugi.Checked)
                    razred = "Drugi";
                if (rbTreci.Checked)
                    razred = "Treci";
                if (rbCetvrti.Checked)
                    razred = "Cetvrti";
                lbSviPodaciUcenika.Items.Add(ime + "  " + razred + "  " + jezik + "  " + smer + "  ");
                txtImeUcenika.Text = "";
                if (jezik == "Srpski")
                    srpskiBroj++;
                if (jezik == "Madjarski")
                    madjarskiBroj++;
                if (smer == "Elektrotehnika")
                    elektroBroj++;
                if (smer == "Saobracaj")
                    saobracajBroj++;
                if (smer == "Masinstvo")
                    masinstvoBroj++;
                label5.Text = srpskiBroj.ToString();
                label6.Text = madjarskiBroj.ToString();
                label7.Text = elektroBroj.ToString();
                label8.Text = masinstvoBroj.ToString();
                label9.Text = saobracajBroj.ToString();
            }
        }
    }
}
