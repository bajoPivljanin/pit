﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dz_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            int i, m = 0, flag = 0;
            int n = Convert.ToInt32(textBox1.Text);
            m = n / 2;
            listBox1.Items.Clear();
            for (i = 2; i <= m; i++)
            {
                if (n % i == 0)
                {
                    label2.Text = "Broj " + n + " nije prost";
                    flag = 1;
                    break;
                }
            }
            if (flag == 0)
                label2.Text = "Broj " + n + " je prost";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBox1.Text);
            listBox1.Items.Clear();
            for (int x = 2; x < n; x++)
            {
                int isPrime = 0;
                for (int y = 1; y < x; y++)
                {
                    if (x % y == 0)
                        isPrime++;

                    if (isPrime == 2) break;
                }
                if (isPrime != 2)
                    listBox1.Items.Add(x);
            }
        }
    }
}
