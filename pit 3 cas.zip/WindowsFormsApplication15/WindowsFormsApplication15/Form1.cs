﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Dinamicko kreiranje Label kontrole
            Label lbl = new Label();
            lbl.Location = new Point(30, 30);
            lbl.AutoSize = true;
            lbl.Font = new Font("Calibri", 14);
            lbl.Text = "Select Programming Language";
            // Dodavanje Label kontrole na formu
            this.Controls.Add(lbl);
            // Dinamicko kreiranje ComboBox kontrole
            ComboBox cb = new ComboBox();
            cb.Location = new Point(40, 70);
            cb.Size = new Size(220, 30);
            cb.Font = new Font("Calibri", 14);
            cb.Items.Add("C#");
            cb.Items.Add("Java");
            cb.Items.Add("C");
            cb.Items.Add("C++");
            cb.Items.Add("Python");
            // Dodavanje ComboBox kontrole na formu
            this.Controls.Add(cb);
        }
    }
}
