﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication16
{
    public partial class Form1 : Form
    {
            string[] telefoni =
            {
                "Samsung","Huawei","Motorola"
            };
            string[] modeliS =
            {
                "Samsung Galaxy A53 5G","Samsung Galaxy A52S 5G","Samsung Galaxy A33","Samsung Galaxy A13 NE"
            };
            int[] modeliSCena = { 53000, 40000, 43000, 25000 };
            string[] modeliH =
            {
                "Huawei Nova Y70",
                "Huawei Nova Y90",
                "Huawei Nova 9SE",
                "Huawei P50 Pro",
                "Huawei Nova 10",
            };
            int[] modeliHCena = { 22000, 28000, 40000, 150000, 70000 };
            string[] modeliM =
            {
                "Motorola Edge 20",
                "Motorola Moto G52",
                "Motorola Moto G41",
                "Motorola Edge 20 Pro"
            };
            int[] modeliMCena = { 33000, 20000, 25000, 45000 };
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = telefoni;
            listBox1.DataSource = modeliS;
            textBox1.Text = modeliSCena[listBox1.SelectedIndex].ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Samsung")
                listBox1.DataSource = modeliS;

            if (comboBox1.SelectedItem.ToString() == "Huawei")
                listBox1.DataSource = modeliH;

            if (comboBox1.SelectedItem.ToString() == "Motorola")
                listBox1.DataSource = modeliM;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Samsung")
                textBox1.Text = modeliSCena[listBox1.SelectedIndex].ToString();

            if (comboBox1.SelectedItem.ToString() == "Huawei")
                textBox1.Text = modeliHCena[listBox1.SelectedIndex].ToString();

            if (comboBox1.SelectedItem.ToString() == "Motorola")
                textBox1.Text = modeliMCena[listBox1.SelectedIndex].ToString();
        }  
    }
}
