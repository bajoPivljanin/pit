﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] lb1 =
        {
            "Kilometar","Metar","Milja","Stopa","Inč"
        };
        string[] lb2 =
        {
            "Celzijus","Ferenhajt"
        };
        string[] lb3 =
        {
            "litar","Americki galon"
        };
        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            listBox1.Items.AddRange(lb1);
            listBox2.Items.AddRange(lb1);
            listBox3.Items.AddRange(lb3);
            listBox4.Items.AddRange(lb3);
            listBox5.Items.AddRange(lb2);
            listBox6.Items.AddRange(lb2);
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string[] listTemp = lb1;
                int val = int.Parse(textBox1.Text);
                switch (listBox1.SelectedIndex.ToString())
                {
                    case "0":
                        listTemp[0] = "Kilometar - " + val;
                        listTemp[1] = "Metar - " + val * 1000;
                        listTemp[2] = "Milja - " + val / 1.609;
                        listTemp[3] = "Stopa - " + val / 3.28;
                        listTemp[4] = "Inc - " + val * 39.37;

                        break;
                    case "1":
                        listTemp[0] = "Kilometar - " + (float)val / 1000;
                        listTemp[1] = "Metar - " + val;
                        listTemp[2] = "Milja - " + (float)val / 1609;
                        listTemp[3] = "Stopa - " + val / 3.28;
                        listTemp[4] = "Inc - " + val * 39370;
                        break;
                    case "2":
                        listTemp[0] = "Kilometar - " + val * 1.609;
                        listTemp[1] = "Metar - " + val * 1609;
                        listTemp[2] = "Milja - " + val;
                        listTemp[3] = "Stopa - " + val * 5280;
                        listTemp[4] = "Inc - " + val * 63360;
                        break;
                    case "3":
                        listTemp[0] = "Kilometar - " + val / 3.280;
                        listTemp[1] = "Metar - " + val / 3.28;
                        listTemp[2] = "Milja - " + val / 5.280;
                        listTemp[3] = "Stopa - " + val;
                        listTemp[4] = "Inc - " + val * 12;
                        break;
                    case "4":
                        listTemp[0] = "Kilometar - " + val / 39.370;
                        listTemp[1] = "Metar - " + val / 39.37;
                        listTemp[2] = "Milja - " + val / 63.360;
                        listTemp[3] = "Stopa - " + val / 12;
                        listTemp[4] = "Inc - " + val;
                        break;
                }
                listBox2.Items.Clear();
                listBox2.Items.AddRange(listTemp);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string[] listTemp = new string[2];
                int val = int.Parse(textBox3.Text);
                switch (listBox5.SelectedIndex.ToString())
                {
                    case "0":
                        listTemp[0] = "Celzijus - " + val;
                        listTemp[1] = "Ferenhajt - " + ((val * 9 / 5) + 32);

                        break;
                    case "1":
                        listTemp[0] = "Celzijus - " + ((val - 32) * 5 / 9);
                        listTemp[1] = "Ferenhajt - " + val;
                        break;
                }
                listBox6.Items.Clear();
                listBox6.Items.AddRange(listTemp);
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string[] listTemp = new string[2];
                int val = int.Parse(textBox2.Text);
                switch (listBox3.SelectedIndex.ToString())
                {
                    case "0":
                        listTemp[0] = "Litar - " + val ;
                        listTemp[1] = "Americki galon - " + val/ 3.785;

                        break;
                    case "1":
                        listTemp[0] = "Litar - " + val* 3.785;
                        listTemp[1] = "Americki galon - " + val;
                        break;
                }
                listBox4.Items.Clear();

                listBox4.Items.AddRange(listTemp);
            }

        }
    }
}
